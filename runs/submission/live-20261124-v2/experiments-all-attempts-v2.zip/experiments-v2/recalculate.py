"""Reconcile measured API calls without counting duplicate result/summary usage."""
import json
from collections import Counter
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCAL = ROOT / 'attempts'
RATE_IN = Decimal('0.30') / 1_000_000
RATE_OUT = Decimal('1.20') / 1_000_000

def read(path):
    return json.loads(path.read_text())

def price(i, o):
    return str(i * RATE_IN + o * RATE_OUT)

sessions = []
ledger = []
for name in ['deepseek-dev-20261123', 'deepseek-dev-20261123-r2', 'deepseek-visible-20261123', 'deepseek-visible-20261124-continuation', 'deepseek-visible-20261124-v2']:
    directory = LOCAL / name
    summary = read(directory / 'summary.json')
    records = []
    for cid in summary['planned_case_ids']:
        case = directory / cid
        if not (case / 'result.json').exists():
            records.append({'case_id': cid, 'status': 'missing'})
            continue
        result = read(case / 'result.json')
        events = [json.loads(line) for line in (case / 'events.jsonl').read_text().splitlines()]
        calls = []
        for event in events:
            if event['name'] != 'llm' or event['event_type'] != 'started':
                continue
            terminal = [e for e in events if e['step_id'] == event['step_id'] and (
                (e['name'] == 'llm' and e['event_type'] == 'succeeded') or e['name'] == 'llm_incomplete_usage')]
            assert len(terminal) <= 1, 'Duplicate measurement'
            item = {'session': name, 'case_id': cid, 'step_id': event['step_id'], 'timestamp_utc': event['timestamp_utc']}
            if terminal:
                u = terminal[0]['output']
                item.update(input_tokens=u['input_tokens'], output_tokens=u['output_tokens'], usage_known=True,
                            reference_cost_usd=price(u['input_tokens'], u['output_tokens']))
            else:
                item.update(input_tokens=None, output_tokens=None, usage_known=False, reference_cost_usd=None,
                            reserved_input_bound=event['input']['input_token_bound'],
                            reserved_output_cap=event['input']['max_tokens'],
                            reference_reservation_usd=price(event['input']['input_token_bound'], event['input']['max_tokens']))
            calls.append(item)
            ledger.append(item)
        known = [x for x in calls if x['usage_known']]
        i = sum(x['input_tokens'] for x in known)
        o = sum(x['output_tokens'] for x in known)
        unknown = len(calls) - len(known)
        assert len(calls) == result['usage']['llm_calls']
        if not unknown:
            assert (i, o) == (result['usage']['input_tokens'], result['usage']['output_tokens'])
            assert abs(Decimal(str(result['usage']['cost'])) - Decimal(price(i, o))) < Decimal('1e-15')
        records.append({'case_id': cid, 'status': result['status'], 'stop_reason': result['stop_reason'],
                        'measured_input_tokens': i, 'measured_output_tokens': o, 'unknown_usage_calls': unknown,
                        'reference_cost_known_usd': price(i, o)})
    i = sum(r.get('measured_input_tokens', 0) for r in records)
    o = sum(r.get('measured_output_tokens', 0) for r in records)
    sessions.append({'session': name, 'planned': summary['planned'], 'recorded': summary['recorded'],
                     'statuses': dict(Counter(r['status'] for r in records)),
                     'measured_input_tokens': i, 'measured_output_tokens': o,
                     'unknown_usage_calls': sum(r.get('unknown_usage_calls', 0) for r in records),
                     'reference_cost_known_usd': price(i, o), 'cases': records})

raw = read(ROOT / 'diagnostics/dev04-diagnostic-response.json')
u = raw['usage']
assert u['total_tokens'] == u['prompt_tokens'] + u['completion_tokens']
ledger.append({'session': 'diagnostic', 'case_id': 'dev-04', 'request_id': raw['id'],
               'input_tokens': u['prompt_tokens'], 'output_tokens': u['completion_tokens'], 'usage_known': True,
               'reasoning_tokens_included_in_output': u['completion_tokens_details']['reasoning_tokens'],
               'reference_cost_usd': price(u['prompt_tokens'], u['completion_tokens'])})
known = [x for x in ledger if x['usage_known']]
i = sum(x['input_tokens'] for x in known)
o = sum(x['output_tokens'] for x in known)
report = {'method': 'One terminal API usage measurement per started call; result and summary used only for cross-checks. Reasoning is included in output, never added twice.',
          'pricing': {'kind': 'reference_only_not_proxy_invoice', 'source': 'https://api-docs.deepseek.com/quick_start/pricing/',
                      'reference_model': 'DeepSeek-V4.1-Flash-1017', 'called_model': 'DeepSeek-V4-Flash-0731',
                      'basis': 'Fixed peak cache-miss rates for conservative comparison, not time-specific billing',
                      'input_usd_per_million': '0.30', 'output_usd_per_million': '1.20'},
          'sessions': sessions, 'calls': ledger,
          'total': {'measured_calls': len(known), 'unknown_usage_calls': len(ledger)-len(known),
                    'measured_input_tokens': i, 'measured_output_tokens': o, 'measured_total_tokens': i+o,
                    'reference_cost_known_usd': price(i, o),
                    'unknown_reference_reservation_usd': str(sum((Decimal(x['reference_reservation_usd']) for x in ledger if not x['usage_known']), Decimal(0))),
                    'complete_actual_token_total': None if len(known) != len(ledger) else i+o,
                    'actual_proxy_charge_usd': None},
          'evaluation_notes': ['Independent human evaluation of these model outputs is pending; published annotation labels are not output ratings.',
                               'CLI actions were performed by Codex; human_active_seconds is not measured human labor.',
                               'Failed first attempt and diagnostic are included, not hidden as retries.']}
(ROOT / 'usage.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'sessions': [{k:v for k,v in s.items() if k != 'cases'} for s in sessions], 'total': report['total']}, indent=2))
